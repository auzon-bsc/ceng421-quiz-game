# How to compile

## Server

gcc server.c -o Server <br>

## Client

gcc client.c -o Client <br>

# How to run

Open 3 terminals<br>

## In terminal 1
./Server <br>

## In terminal 2
./Client <br>

## In terminal 3
./Client <br>

# Lastly

Enjoy <br>